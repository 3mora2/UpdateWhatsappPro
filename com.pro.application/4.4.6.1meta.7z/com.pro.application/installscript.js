
function Component()
{
    // default constructor
}


Component.prototype.createOperations = function()
{
    component.createOperations();
    if (installer.value("os") === "win") {
      component.addOperation("CreateShortcut", "@TargetDir@/main.exe", "@StartMenuDir@/WhatsApp Pro.lnk");
      component.addOperation("CreateShortcut", "@TargetDir@/main.exe", "@DesktopDir@/WhatsApp Pro.lnk");
    }
    var reg = installer.environmentVariable("SystemRoot") + "\\System32\\reg.exe";
    var key= "HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Layers" ;
    component.addElevatedOperation("Execute",reg, "ADD",key, "/reg:64" ,"/v","@TargetDir@\\main.exe","/t","REG_SZ","/d","~ RUNASADMIN", "/f");


}
